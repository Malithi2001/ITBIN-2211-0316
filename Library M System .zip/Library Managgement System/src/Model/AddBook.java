/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Malithi
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AddBook {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/librarydb";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";



    public void addBook(int bID, String bName, String cat, String aut, int copy) throws SQLException {
        String query = "INSERT INTO book (book_ID, book_Name, category, author,copies) VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, bID);
            statement.setString(2, bName);
            statement.setString(3, cat);
            statement.setString(4, aut);
            statement.setInt(5, copy);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new SQLException("Error adding Book: " + e.getMessage());
        }
    }
}
