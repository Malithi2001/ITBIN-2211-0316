/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Malithi
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException; 

public class AddMember {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/librarydb";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";


    public void addMember(int telephone, String mName, int mID, String gender, int age) throws SQLException {
        String query = "INSERT INTO members (member_ID, member_Name, age, gender,telephone) VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, mID);
            statement.setString(2, mName);
            statement.setInt(3, age);
            statement.setString(4, gender);
            statement.setInt(5, telephone);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new SQLException("Error adding Member: " + e.getMessage());
        }
    }
    
    
    
    
    
    
    
    
}