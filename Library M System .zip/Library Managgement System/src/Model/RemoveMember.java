/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Malithi
 */
public class RemoveMember {
     public static void removeMember(int mID) throws SQLException {
        String sql = "DELETE FROM members WHERE member_ID = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, mID);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("No account found with account number: " + mID);
            }
        } catch (SQLException e) {
            throw new SQLException("Error removing account: " + e.getMessage(), e);
        }
    }
}
