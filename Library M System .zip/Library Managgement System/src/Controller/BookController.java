/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.AddBook;
import Model.RemoveBook;
import java.sql.SQLException;

/**
 *
 * @author Malithi
 */
public class BookController {
    public static void addBook(int bID, String bName, String cat, String aut, int copy) 
            throws SQLException {
        AddBook addBook = new AddBook();
        addBook.addBook(bID, bName, cat, aut, copy);
    }
    public void removeBook(int bID) throws SQLException {
        RemoveBook.removeBook(bID);
    }
}
