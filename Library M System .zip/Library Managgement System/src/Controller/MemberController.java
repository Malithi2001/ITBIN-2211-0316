/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;



/**
 *
 * @author Malithi
 */
import Model.AddMember;
import Model.RemoveMember;
import java.sql.SQLException;

public class MemberController {
    
    public static void addMember(int telephone, String mName, int mID, int age, String gender) 
            throws SQLException {
        AddMember addMember = new AddMember();
        addMember.addMember(telephone, mName, mID, gender, age);
    
}

    
  public void removeMember(int mID) throws SQLException {
        RemoveMember.removeMember(mID);
    }  

    public void removeBook(int bID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
